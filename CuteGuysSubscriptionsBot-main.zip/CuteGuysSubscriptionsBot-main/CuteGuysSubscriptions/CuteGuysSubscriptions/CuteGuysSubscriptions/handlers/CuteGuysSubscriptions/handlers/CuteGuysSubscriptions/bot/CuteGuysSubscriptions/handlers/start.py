from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

router = Router()


@router.message(CommandStart())
async def start(message: Message):

    texto = """
👑 <b>Cute Guys Subscriptions</b>

Bienvenido.

Aquí podrás comprar tus suscripciones VIP de una forma rápida y segura.

⭐ Telegram Stars
💳 CryptoBot
🟡 Binance Pay
🅿️ PayPal

Próximamente podrás abrir la tienda desde el botón inferior.
"""

    await message.answer(texto)
