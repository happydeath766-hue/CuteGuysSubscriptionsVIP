"""
═══════════════════════════════════════
👑 Cute Guys Subscriptions

Archivo principal

Versión 1.0
═══════════════════════════════════════
"""

import asyncio

from bot.loader import bot, dp
from handlers.start import router


async def main():
    dp.include_router(router)

    await bot.delete_webhook(drop_pending_updates=True)

    print("👑 Cute Guys Subscriptions iniciado correctamente")

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
