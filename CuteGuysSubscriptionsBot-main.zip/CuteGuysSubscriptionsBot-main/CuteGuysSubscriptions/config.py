"""
=================================================
👑 Cute Guys Subscriptions

Configuración General

Versión: 1.0.0
=================================================
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ========= BOT =========

BOT_TOKEN = os.getenv("BOT_TOKEN")

# ========= WEB =========

WEBAPP_URL = os.getenv("WEBAPP_URL")

# ========= SOPORTE =========

SUPPORT_USERNAME = os.getenv(
    "SUPPORT_USERNAME",
    "@CuteGuyspg"
)

# ========= ADMIN =========

ADMIN_GROUP_ID = int(
    os.getenv("ADMIN_GROUP_ID", "0")
)

# ========= GRUPOS VIP =========

VIP1_GROUP_ID = int(
    os.getenv("VIP1_GROUP_ID", "0")
)

VIP2_GROUP_ID = int(
    os.getenv("VIP2_GROUP_ID", "0")
)

CUSTOM_GROUP_ID = int(
    os.getenv("CUSTOM_GROUP_ID", "0")
)

# ========= PAYPAL =========

PAYPAL_LINK = os.getenv("PAYPAL_LINK")

PAYPAL_USER = os.getenv("PAYPAL_USER")

# ========= CRYPTOBOT =========

CRYPTBOT_TOKEN = os.getenv("CRYPTBOT_TOKEN")

# ========= BINANCE =========

BINANCE_ID = os.getenv("BINANCE_ID")

# ========= DATABASE =========

DATABASE_URL = os.getenv("DATABASE_URL")
