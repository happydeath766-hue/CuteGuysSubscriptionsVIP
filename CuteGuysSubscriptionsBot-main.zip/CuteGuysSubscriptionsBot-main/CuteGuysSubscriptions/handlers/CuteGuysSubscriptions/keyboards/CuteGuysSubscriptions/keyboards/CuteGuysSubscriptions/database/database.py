import asyncpg
from config import DATABASE_URL

pool = None

async def connect_db():
    global pool

    pool = await asyncpg.create_pool(DATABASE_URL)

    async with pool.acquire() as conn:

        await conn.execute("""

        CREATE TABLE IF NOT EXISTS users (

            user_id BIGINT PRIMARY KEY,

            username TEXT,

            first_name TEXT,

            language TEXT DEFAULT 'es',

            created_at TIMESTAMP DEFAULT NOW()

        );

        """)

        await conn.execute("""

        CREATE TABLE IF NOT EXISTS subscriptions (

            id SERIAL PRIMARY KEY,

            user_id BIGINT,

            plan TEXT,

            expires_at TIMESTAMP,

            active BOOLEAN DEFAULT TRUE

        );

        """)

        await conn.execute("""

        CREATE TABLE IF NOT EXISTS payments (

            id SERIAL PRIMARY KEY,

            user_id BIGINT,

            method TEXT,

            amount NUMERIC,

            status TEXT,

            created_at TIMESTAMP DEFAULT NOW()

        );

        """)

        print("✅ Base de datos lista")
