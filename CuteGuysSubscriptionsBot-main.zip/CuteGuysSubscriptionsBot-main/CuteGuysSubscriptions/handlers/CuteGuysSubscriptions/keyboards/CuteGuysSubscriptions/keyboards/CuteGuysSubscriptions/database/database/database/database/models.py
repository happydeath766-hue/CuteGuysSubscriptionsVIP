from database.database import execute


async def create_tables():

    await execute("""

    CREATE TABLE IF NOT EXISTS users(

        user_id BIGINT PRIMARY KEY,

        username TEXT,

        first_name TEXT,

        language TEXT DEFAULT 'es',

        created_at TIMESTAMP DEFAULT NOW()

    );

    """)

    await execute("""

    CREATE TABLE IF NOT EXISTS subscriptions(

        id SERIAL PRIMARY KEY,

        user_id BIGINT,

        plan TEXT,

        expires_at TIMESTAMP,

        active BOOLEAN DEFAULT TRUE

    );

    """)

    await execute("""

    CREATE TABLE IF NOT EXISTS payments(

        id SERIAL PRIMARY KEY,

        user_id BIGINT,

        payment_method TEXT,

        amount NUMERIC,

        status TEXT,

        created_at TIMESTAMP DEFAULT NOW()

    );

    """)

    print("✅ Tablas creadas.")
