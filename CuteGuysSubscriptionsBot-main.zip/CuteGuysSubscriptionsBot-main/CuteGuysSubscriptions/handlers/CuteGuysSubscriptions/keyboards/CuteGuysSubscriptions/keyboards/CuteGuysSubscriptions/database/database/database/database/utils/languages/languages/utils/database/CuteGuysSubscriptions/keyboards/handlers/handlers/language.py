from aiogram import Router
from aiogram import F
from aiogram.types import CallbackQuery

router = Router()


@router.callback_query(F.data == "language")
async def language(callback: CallbackQuery):

    await callback.answer()

    await callback.message.answer(
        "🌍 Language selector\n\n"
        "🚧 Coming soon."
    )
