import asyncio

from bot.loader import bot, dp

from database.database import connect
from database.models import create_tables

from handlers.start import router as start_router
from handlers.profile import router as profile_router
from handlers.language import router as language_router


async def main():

    await connect()

    await create_tables()

    dp.include_router(start_router)
    dp.include_router(profile_router)
    dp.include_router(language_router)

    await bot.delete_webhook(drop_pending_updates=True)

    print("👑 Cute Guys Subscriptions iniciado")

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
