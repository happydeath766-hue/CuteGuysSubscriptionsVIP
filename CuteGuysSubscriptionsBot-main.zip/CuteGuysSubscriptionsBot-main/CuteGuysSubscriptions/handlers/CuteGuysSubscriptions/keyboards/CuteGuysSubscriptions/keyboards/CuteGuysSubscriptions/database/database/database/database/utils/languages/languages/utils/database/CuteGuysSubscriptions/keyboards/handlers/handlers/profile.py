from aiogram import Router
from aiogram import F
from aiogram.types import CallbackQuery

router = Router()


@router.callback_query(F.data == "profile")
async def profile(callback: CallbackQuery):

    await callback.answer()

    await callback.message.answer(
        "👤 Your profile will appear here.\n\n"
        "🚧 Under development."
    )
