const PRODUCTS=[

{

id:"vip1",

name:"VIP 1",

price:15,

stars:800

},

{

id:"vip2",

name:"VIP 2",

price:10,

stars:500

},

{

id:"custom",

name:"Personalizado",

price:70,

stars:3500

},

{

id:"combo",

name:"VIP 1 + VIP 2",

price:17

},

{

id:"combo2",

name:"Personalizado + Otro",

price:80

},

{

id:"all",

name:"Todo",

price:90

}

];
