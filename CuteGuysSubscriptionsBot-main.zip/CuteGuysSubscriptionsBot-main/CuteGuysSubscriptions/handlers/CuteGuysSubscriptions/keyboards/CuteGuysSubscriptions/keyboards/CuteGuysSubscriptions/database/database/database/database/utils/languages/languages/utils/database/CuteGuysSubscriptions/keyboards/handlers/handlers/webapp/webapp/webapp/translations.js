const LANG={

es:{

buy:"Comprar",

checkout:"Continuar"

},

en:{

buy:"Buy",

checkout:"Continue"

}

};
