const tg=window.Telegram.WebApp;

tg.expand();

const plans=document.getElementById("plans");

PRODUCTS.forEach(product=>{

plans.innerHTML+=`

<div class="card">

<h2>${product.name}</h2>

<h3>$${product.price}</h3>

${product.stars?`<p>${product.stars} ⭐</p>`:""}

<button onclick="buy('${product.id}')">

Comprar

</button>

</div>

`;

});

function buy(id){

alert("Próximamente se abrirá el Checkout de "+id);

  }
