const tg=window.Telegram.WebApp;

tg.expand();

const plans=document.getElementById("plans");

PRODUCTS.forEach(product=>{

plans.innerHTML+=`

<div class="card">

<h2>${product.name}</h2>

<div class="price">

$${product.price}

</div>

${product.stars?

`<div class="stars">

⭐ ${product.stars} Telegram Stars

</div>`:""}

<button

class="buy"

onclick="selectProduct('${product.id}')">

Comprar

</button>

</div>

`;

});

function selectProduct(id){

localStorage.setItem("product",id);

window.location="#checkout";

alert("Checkout próximamente.");

}
