let selectedProduct = null;

function selectProduct(id){

    selectedProduct = PRODUCTS.find(p => p.id === id);

    renderCheckout();

}

function renderCheckout(){

    const checkout = document.getElementById("checkout");

    checkout.innerHTML = `

        <div class="checkout-card">

            <h2>${selectedProduct.name}</h2>

            <div class="checkout-price">

                $${selectedProduct.price}

            </div>

            <div class="payment-title">

                Selecciona un método de pago

            </div>

            <button class="pay-btn stars"
            onclick="payStars()">

                ⭐ Telegram Stars

            </button>

            <button class="pay-btn crypto"
            onclick="payCrypto()">

                🤖 CryptoBot

            </button>

            <button class="pay-btn paypal"
            onclick="payPaypal()">

                🅿️ PayPal

            </button>

            <button class="pay-btn binance"
            onclick="payBinance()">

                🟡 Binance Pay

            </button>

            <button class="pay-btn receipt"
            onclick="manualPayment()">

                📷 Enviar comprobante

            </button>

        </div>

    `;

}
