function payPaypal(){

    window.open(
        "https://paypal.me/Worldtwinks",
        "_blank"
    );

}

function payBinance(){

    alert(
        "Escanea el código QR de Binance."
    );

}

function payCrypto(){

    alert(
        "Conectando con CryptoBot..."
    );

}

function payStars(){

    alert(
        "Próximamente Telegram Stars."
    );

}

function manualPayment(){

    Telegram.WebApp.sendData(JSON.stringify({

        action:"receipt",

        product:selectedProduct.id

    }));

    Telegram.WebApp.close();

}
