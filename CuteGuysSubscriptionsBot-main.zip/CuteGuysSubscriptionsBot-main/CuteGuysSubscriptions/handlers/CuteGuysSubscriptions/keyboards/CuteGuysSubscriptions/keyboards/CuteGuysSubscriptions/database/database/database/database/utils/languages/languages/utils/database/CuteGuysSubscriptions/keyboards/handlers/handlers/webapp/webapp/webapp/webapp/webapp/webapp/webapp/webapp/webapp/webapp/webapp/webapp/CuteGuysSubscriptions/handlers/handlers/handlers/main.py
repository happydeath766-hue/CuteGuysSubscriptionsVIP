from handlers.payment import router as payment_router
from handlers.receipt import router as receipt_router
dp.include_router(payment_router)
dp.include_router(receipt_router)
