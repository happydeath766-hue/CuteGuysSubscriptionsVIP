from aiogram import Router
from aiogram import F
from aiogram.types import CallbackQuery

from handlers.receipt import waiting_users

router = Router()

@router.callback_query(F.data.startswith("manual_"))
async def manual(callback: CallbackQuery):

    _, product, price, method = callback.data.split("|")

    waiting_users[callback.from_user.id] = {

        "product": product,

        "price": price,

        "method": method

    }

    await callback.message.answer(

        "📷 Ahora envía una captura de pantalla del pago."

    )

    await callback.answer()
