from aiogram import Router, F
from aiogram.types import Message
from config import ADMIN_GROUP_ID

router = Router()

waiting_users = {}

@router.message(F.photo)
async def receive_receipt(message: Message):

    if message.from_user.id not in waiting_users:
        return

    data = waiting_users.pop(message.from_user.id)

    caption = f"""
💳 <b>Nuevo comprobante recibido</b>

👤 Usuario:
{message.from_user.full_name}

🆔 ID:
<code>{message.from_user.id}</code>

📦 Producto:
{data["product"]}

💰 Precio:
{data["price"]} USD

Método:
{data["method"]}
"""

    await message.bot.send_photo(
        chat_id=ADMIN_GROUP_ID,
        photo=message.photo[-1].file_id,
        caption=caption
    )

    await message.answer(
        "✅ Tu comprobante fue enviado.\n\n"
        "Un administrador lo revisará."
    )
