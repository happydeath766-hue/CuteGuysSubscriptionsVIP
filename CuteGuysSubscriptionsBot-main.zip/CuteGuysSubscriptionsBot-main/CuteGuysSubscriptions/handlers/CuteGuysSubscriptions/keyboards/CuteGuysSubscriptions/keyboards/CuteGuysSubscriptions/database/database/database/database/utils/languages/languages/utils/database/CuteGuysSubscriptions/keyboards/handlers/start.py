from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

from keyboards.main_menu import main_menu
from utils.register_user import register_user

router = Router()


@router.message(CommandStart())
async def start(message: Message):

    await register_user(message)

    texto = f"""
👑 <b>Cute Guys Subscriptions</b>

━━━━━━━━━━━━━━━━━━

✨ Welcome!

Access exclusive subscriptions safely and quickly.

━━━━━━━━━━━━━━━━━━

💎 Available methods

⭐ Telegram Stars

💳 CryptoBot

🟡 Binance Pay

🅿️ PayPal

━━━━━━━━━━━━━━━━━━

Choose an option below.
"""

    await message.answer(
        texto,
        reply_markup=main_menu()
    )
