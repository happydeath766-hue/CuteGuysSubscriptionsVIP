from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    WebAppInfo
)

from config import (
    WEBAPP_URL,
    SUPPORT_USERNAME
)


def main_menu():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🛒 Explore Subscriptions",
                    web_app=WebAppInfo(url=WEBAPP_URL)
                )
            ],

            [
                InlineKeyboardButton(
                    text="👤 My Subscription",
                    callback_data="profile"
                ),

                InlineKeyboardButton(
                    text="🌍 Language",
                    callback_data="language"
                )
            ],

            [
                InlineKeyboardButton(
                    text="💬 Support",
                    url=f"https://t.me/{SUPPORT_USERNAME.replace('@','')}"
                )
            ]
        ]
          )
