import json


def load_language(lang):

    with open(

        f"languages/{lang}.json",

        encoding="utf8"

    ) as file:

        return json.load(file)
