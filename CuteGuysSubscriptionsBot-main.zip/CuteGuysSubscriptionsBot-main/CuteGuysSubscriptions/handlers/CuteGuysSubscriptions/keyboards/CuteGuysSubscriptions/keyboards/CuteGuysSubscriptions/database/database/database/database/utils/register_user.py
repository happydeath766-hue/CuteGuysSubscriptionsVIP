from database.database import execute


async def register_user(message):

    await execute(

        """

        INSERT INTO users(

            user_id,

            username,

            first_name

        )

        VALUES($1,$2,$3)

        ON CONFLICT(user_id)

        DO NOTHING;

        """,

        message.from_user.id,

        message.from_user.username,

        message.from_user.first_name

    )
