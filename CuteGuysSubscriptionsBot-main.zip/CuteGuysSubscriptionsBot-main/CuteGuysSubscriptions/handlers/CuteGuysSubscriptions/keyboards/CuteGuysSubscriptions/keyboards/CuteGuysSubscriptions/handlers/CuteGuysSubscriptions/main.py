import asyncio

from bot.loader import bot, dp

from handlers.start import router

dp.include_router(router)


async def main():

    await bot.delete_webhook(
        drop_pending_updates=True
    )

    print("👑 Cute Guys Subscriptions iniciado")

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
