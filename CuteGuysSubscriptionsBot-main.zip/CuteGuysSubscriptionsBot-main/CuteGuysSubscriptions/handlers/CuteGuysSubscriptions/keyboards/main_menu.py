from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    WebAppInfo
)

from config import (
    WEBAPP_URL,
    SUPPORT_USERNAME
)


def main_menu():

    return InlineKeyboardMarkup(
        inline_keyboard=[

            [
                InlineKeyboardButton(
                    text="🛒 Abrir Tienda",
                    web_app=WebAppInfo(
                        url=WEBAPP_URL
                    )
                )
            ],

            [
                InlineKeyboardButton(
                    text="💬 Soporte",
                    url=f"https://t.me/{SUPPORT_USERNAME.replace('@','')}"
                )
            ],

            [
                InlineKeyboardButton(
                    text="🌍 Idioma",
                    callback_data="language"
                )
            ]

        ]
    )
