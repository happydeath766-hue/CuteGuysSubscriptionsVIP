"""
====================================================
👑 Cute Guys Subscriptions

Comando /start

Versión 1.0
====================================================
"""

from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

from keyboards.main_menu import main_menu

router = Router()


@router.message(CommandStart())
async def start(message: Message):

    texto = f"""
👑 <b>Cute Guys Subscriptions</b>

✨ Bienvenido a la plataforma oficial de suscripciones.

Aquí podrás adquirir acceso a nuestros grupos VIP de forma segura.

⭐ Telegram Stars
💳 CryptoBot
🟡 Binance Pay
🅿️ PayPal

👇 Pulsa el botón de abajo para comenzar.
"""

    await message.answer(
        texto,
        reply_markup=main_menu()
    )
